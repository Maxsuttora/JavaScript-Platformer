import processing.core.*;
class Gamelogo extends PApplet { 

  PImage Crownlogo;
  private PApplet p;

  public Gamelogo(PApplet p) {
    this.p=p;
  }
  void display() {
    p.imageMode(p.CENTER);
    p.fill(0);
    Crownlogo = p.loadImage("crown.png");
    Crownlogo.resize(853, 640);
    p.image(Crownlogo, p.width/2, p.height/2-20);


    p.textAlign(p.CENTER);
    p.textSize((p.height/22));
    p.text("Camelot Quest", p.width/2, p.height * 2.5f/3);
    p.textSize(17);
    p.text("CS-104 Final Project Spring 2022", p.width/5.75f, p.height *9.5f/10);
    p.text("Sam Greenberg, Fritz Pingel, Maxwell Suttora, Chris Prahl, Cameron Berke", p.width/2, p.height*2.2f/2.8f);
    p.text("Press Enter to continue", p.width - p.width/5.75f, p.height *9.5f/10);
  }
}
