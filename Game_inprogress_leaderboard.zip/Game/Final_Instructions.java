import processing.core.*;

class Game_Instructions extends PApplet {

  public PImage start;
  private PApplet p;
  private String[] ListNames= {" "};
  //Array to store score
  private String[] ListScore= {" "};
  //Array to store key 
  public char[] key_l={' '};
  // Variable for name and score
  public String typed=new String(key_l);
  //variables to control game
  //private boolean w_names=true;
  //private boolean w_score=false;
  //private boolean w_Leader=false;
  private int aw=60;
  private int ah=15;
  private boolean w_names=true;
  private boolean w_score=false;
  private boolean w_Leader=false;
  //private boolean clicked = false;
  //private boolean intbackPressed = false;
  private boolean startPressed = false;
  public boolean mainInstructions;
  public boolean addInstructions;
  public boolean done=false;
  public Game_Instructions(PApplet p, boolean mainInstructions, boolean addInstructions) {
    this.p=p;
    this.mainInstructions=mainInstructions;
    this.addInstructions=addInstructions;
  }

  //public void startPressed() {
  //  if (startPressed==true) {
  //    mainInstructions=false;
  //    addInstructions=false;
  //    enterName();
  //    //AFTER NAME ENTERED GAMESTATE CHANGES TO NEXT LEVEL
  //  }
  //}

  public void showINSTRUCTIONS() {
    if (mainInstructions==true) {
      p.textAlign(p.CENTER);
      p.fill(95, 59, 1);
      p.text("INSTRUCTIONS:", p.width/2, p.height/8);
      p.fill(95, 59, 1);
      p.text("OBJECTIVES:", p.width/2, p.height/8+150);
      p.fill(0);
      p.textSize(15);
      p.text("-WATCH OUT FOR ENEMIES ", p.width/2, p.height/2-20);
      p.text("-COLLECT COINS ALONG THE WAY ", p.width/2, p.height/2+30);
      p.text("-COLLECT NEW ABILITIES AT THE END OF EACH LEVEL!", p.width/2, p.height/2+140);
      p.text("-BEAT THE LEVEL QUICKLY TO REACH THE LEADERBOARD", p.width/2, p.height/2+190);
      p.text("", p.width/2, p.height/2+180);
      p.text("", p.width/2, p.height/2+230);
      p.textSize(15);
    }
  }
  public void showSubfont() {
    if (mainInstructions==true) {
      p.fill(0);
      p.text("MOVE FORWARD WITH 'D' KEY", p.width/2, p.height/8+40);
      p.text("MOVE BACKWARDS WITH 'A' KEY ", p.width/2, p.height/8+70);
      p.text("JUMP WITH 'W' KEY", p.width/2, p.height/8+100);
    }
  }

  public void AddINSTRUCTIONS() {
    if (mainInstructions==true) {
      p.size(853, 600);
      p.text("!ADDITIONAL INSTRUCTIONS!", p.width/6, p.height/3);
      p.rectMode(p.CENTER);
      p.stroke(170);
      p.strokeWeight(1.8f);
      p.fill(224, 22, 0);
      p.rect(p.width/6, p.height/3+19, aw, ah);
      p.fill(255);
      p.text("CLICK HERE", p.width/6, p.height/3+20);
    }
  }

  public void addintPress() {
    p.textSize(25);
    p.fill(0);
    p.text("ADDITIONAL INSTRUCTIONS:", p.width/2, p.height/8);
    p.textSize(15);
    p.text("HOW TO DIE:", p.width/4, p.height/4);
    p.fill(0);
    p.text("HOW TO WIN:", p.width-p.width/4, p.height/4);
    p.textSize(10);
    p.fill(229, 2, 21);
    p.text("1. FALL OFF THE MAP", p.width/4, p.height/4+50);
    p.text("2. GET BIT BY SPIDER", p.width/4, p.height/4+90);
    p.text("3. HIT BY ENEMY", p.width/4, p.height/4+210);
    p.textSize(10);
    p.fill(31, 29, 237);
    p.text("1. REACH THE END OF THE MAP", p.width-p.width/4, p.height/4+50);
    p.text("2. COLLECT THE COINS", p.width-p.width/4, p.height/4+90);
    p.text("3. UNLOCK ALL ABILITIES", p.width-p.width/4, p.height/4+210);
    p.stroke(190);
    p.strokeWeight(3);
    p.fill(137, 92, 1, 170);
    p.rect(p.width/2, p.height-p.height/6+7, 150, 50);
    p.fill(255);
    p.text("CLICK HERE TO", p.width/2, p.height-p.height/6);
    p.text("GO BACK TO MAIN", p.width/2, p.height-p.height/6+20);
  }


  //public void intbackPress() {
  //  if (p.mouseX>p.width/6-aw/2&& p.mouseY>p.height/3+19-ah/2 && p.mouseX<p.width/6+aw/2 && p.mouseY<p.height/3+19+ah/2 && clicked)
  //    addintPressed=true;
  //  if (addintPressed==true) {
  //    p.background(244,216,255);
  //    p.tint(244,216,255, 90);
  //    //p.image(backdrop, p.width/2, (p.height/2)+15);
  //    p.textSize(25);
  //    p.fill(0);
  //    p.text("ADDITIONAL INSTRUCTIONS:", p.width/2, p.height/8);
  //    p.textSize(15);
  //    p.text("HOW TO DIE:", p.width/4, p.height/4);
  //    p.textSize(10);
  //    p.fill(229,2,21);
  //    p.text("1.FALL OFF THE MAP", p.width/4, p.height/4+50);
  //    p.text("2.GET BIT BY SPIDER", p.width/4, p.height/4+90);
  //    p.text("3.HIT BY ENEMY", p.width/4, p.height/4+210);
  //    p.tint(255, 255);
  //    //p.image(spider, p.width/4, p.height/4+145);
  //    p.fill(0);
  //    p.text("HOW TO WIN:", p.width-p.width/4, p.height/4);
  //    p.textSize(10);
  //    p.fill(31,29,237);
  //    p.text("1. REACH THE END OF THE MAP", p.width-p.width/4, p.height/4+50);
  //    p.text("2. COLLECT THE COINS", p.width-p.width/4, p.height/4+90);
  //    //p.image(coin, p.width-p.width/4, p.height/4+145);
  //    p.text("3.UNLOCK ALL ABILITIES", p.width-p.width/4, p.height/4+210);
  //    if (addintPressed==true) {
  //      p.stroke(190);
  //      p.strokeWeight(3);
  //      p.fill(137,92,1, 170);
  //      p.rect(p.width/2, p.height-p.height/6+7, 150, 50);
  //      p.fill(255);
  //      p.text("CLICK HERE TO", p.width/2, p.height-p.height/6);
  //      p.text("GO BACK TO MAIN", p.width/2, p.height-p.height/6+20);
  //      if (p.mouseX>p.width/2-150/2&& p.mouseY>p.height-p.height/6+7-50/2 && p.mouseX<p.width/2+150/2 && p.mouseY<p.height-p.height/6+7+50/2 && clicked)
  //        intbackPressed=true;
  //      if (intbackPressed==true) {
  //        showINSTRUCTIONS();
  //        AddINSTRUCTIONS();
  //        if (p.mouseX>p.width/6-aw/2&& p.mouseY>p.height/3+19-ah/2 && p.mouseX<p.width/6+aw/2 && p.mouseY<p.height/3+19+ah/2 && clicked)
  //          mainInstructions=true;
  //        if (mainInstructions==true) {
  //          p.background(244,216,255);
  //          p.tint(244,216,255, 90);
  //          //p.image(backdrop, p.width/2, (p.height/2)+15);
  //          p.textSize(25);
  //          p.fill(0);
  //          p.text("ADDITIONAL INSTRUCTIONS:", p.width/2, p.height/8);
  //          p.textSize(15);
  //          p.text("HOW TO DIE:", p.width/4, p.height/4);
  //          p.textSize(10);
  //          p.fill(229,2,21);
  //          p.text("1.FALL OFF THE MAP", p.width/4, p.height/4+50);
  //          p.text("2.GET BIT BY SPIDER", p.width/4, p.height/4+90);
  //          p.tint(255, 255);
  //          //p.image(spider, p.width/4, p.height/4+145);
  //          p.fill(0);
  //          p.text("HOW TO WIN:", p.width-p.width/4, p.height/4);
  //          p.textSize(10);
  //          p.fill(31,29,237);
  //          p.text("1. REACH THE END OF THE MAP", p.width- p.width/4,  p.height/4+50);
  //          p.text("2. COLLECT THE COINS",  p.width- p.width/4,  p.height/4+90);
  //          //p.image(coin,  p.width- p.width/4,  p.height/4+145);
  //          //text("3.______", p.width-p.width/4, p.height/4+210);
  //          p.stroke(190);
  //          p.strokeWeight(3);
  //          p.fill(137,92,1, 170);
  //          p.rect(p.width/2, p.height-p.height/6+7, 150, 50);
  //          p.fill(255);
  //          p.text("CLICK HERE TO", p.width/2, p.height-p.height/6);
  //          p.text("GO BACK TO MAIN", p.width/2, p.height-p.height/6+20);
  //          if (p.mouseX>p.width/2-150/2&& p.mouseY>p.height-p.height/6+7-50/2 && p.mouseX<p.width/2+150/2 && p.mouseY<p.height-p.height/6+7+50/2 && clicked)
  //            mainInstructions=true;
  //          if (mainInstructions==true) {
  //            p.background(244,216,255);
  //            p.tint(244,216,255, 90);
  //            //p.image(backdrop, p.width/2, (p.height/2)+15);
  //            p.textSize(25);
  //            p.fill(0);
  //            p.text("ADDITIONAL INSTRUCTIONS:", p.width/2, p.height/8);
  //            p.textSize(15);
  //            p.text("HOW TO DIE:", p.width/4, p.height/4);
  //            p.textSize(10);
  //            p.fill(229,2,21);
  //            p.text("1.FALL OFF THE MAP", p.width/4, p.height/4+50);
  //            p.text("2.GET BIT BY SPIDER", p.width/4, p.height/4+90);
  //            //text("3.______", width/4, height/4+210);
  //            p.tint(255, 255);
  //            //p.image(spider, p.width/4, p.height/4+145);
  //            p.fill(0);
  //            p.text("HOW TO WIN:", p.width-p.width/4, p.height/4);
  //            p.textSize(10);
  //            p.fill(31,29,237);
  //            p.text("1. REACH THE END OF THE MAP", p.width-p.width/4, p.height/4+50);
  //            p.text("2. COLLECT THE COINS", p.width-p.width/4, p.height/4+90);
  //            //p.image(coin, p.width-p.width/4, p.height/4+145);
  //            p.strokeWeight(3);
  //            p.fill(137,92,1, 170);
  //            p.rect(p.width/2, p.height-p.height/6+7, 150, 50);
  //            p.fill(255);
  //            p.text("CLICK HERE TO", p.width/2, p.height-p.height/6);
  //            p.text("GO BACK TO MAIN", p.width/2, p.height-p.height/6+20);
  //          }
  //        }
  //      }
  //    }
  //  }
  //}

  //public void mouseReleased() {
  //  clicked = !clicked;
  //}

    ////This will show the page to input sacore
    //if (w_score) {
    //  //This are the instructions
    //  p.textSize(25);
    //  p.text("Type your Score", p.width/2, p.height/2-50 );
    //  p.noFill();
    //  p.stroke(255);
    //  //Bottoms to select paddle size
    //  p.textSize(15);
    //  p.text("Click the mouse to see Leaderboard", p.width/2, p.height-70 );
    //  //This is to make show the name
    //  p.text(typed, p.width/2, p.height/2 );
    //  p.println(typed);

    //  //Logic for moving to the next stage and saving named
    //  if (p.mousePressed) {
    //    if (ListScore[0]!=" ") {
    //      ListScore=p.append(ListScore, typed);
    //    } else {
    //      ListScore[0]=typed;
    //    }
    //    w_score=false;
    //    w_names=true;
    //    typed="  ";
    //    key_l=new char[1];
    //    key_l[0]=' ';
    //  }
    //}

    //This will show the page to input sacore
    //if (w_Leader) {

    //  //This are the instructions
    //  textSize(25);
    //  text("Type your Score", width/2, height/2-50 );
    //  noFill();
    //  stroke(255);
    //  //Bottoms to select paddle size
    //  textSize(15);
    //  text("Click the mouse to go back to the name page", width/2, height-70 );
    //  //This is to make show the name
    //  text(typed, width/2, height/2 );
    //  println(typed);

    //  //Logic for moving to the next stage and saving named
    //  if (mousePressed) {
    //    w_names=true;
    //    w_Leader=false;
    //  }
    //}
  //}

  //This is to add the new charaters to the name array
 public  void keyReleased() {
    key_l = (char[]) p.append(key_l, p.key);
    typed=new String(key_l);
  }
  //}
}
