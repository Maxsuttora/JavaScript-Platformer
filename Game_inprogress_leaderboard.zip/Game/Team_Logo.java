import processing.core.*;

class Team_Logo extends PApplet {

  private PApplet p;

  // Current x-positions of first triangle
  private float currentx1;
  private float currentx2;
  private float currentx3;

  // Current x-positions of second triangle
  private float currentx4;
  private float currentx5;
  private float currentx6;

  private float speed=1.15f; // Speed of triangles

  public Team_Logo(PApplet p) {
    this.p=p;
    currentx1=p.width;
    currentx2=p.width+p.width/4;
    currentx3=p.width-p.width/4;
    currentx4=0;
    currentx5=0-(p.width/4);
    currentx6=p.width/4;
  }

  public void display_logo() { // Display the shapes
    p.background(255);
    p.fill(0, 0, 150, 150);
    p.triangle(currentx1, (p.height/2)+(p.height/4), currentx2, p.height/4, currentx3, p.height/4);
    p.fill(255, 133, 3, 150);
    p.triangle(currentx4, p.height/4, currentx5, (p.height/2)+(p.height/4), currentx6, (p.height/2)+(p.height/4));
  }

  public void display_text() { // Display the text
    if (currentx1<=p.width/2 && currentx4>=p.width/2) {
      p.textSize(p.width/10);
      p.fill(0, 0, 150);
      p.textAlign(p.CENTER);
      p.text("PHONY", p.width/2, p.height/2-p.height/3-p.height/20);
      p.textSize(p.width/20);
      p.text("Processing Entertainment", p.width/2, p.height/2+p.height/3+p.height/20);
      p.textSize(17);
      p.text("Press the Space bar to continue", p.width - p.width/5.75f, p.height *9.5f/10);
    }
  }

  public void animation() { // Move the shapes
    if (currentx1>p.width/2) {
      currentx1-=speed;
      currentx2-=speed;
      currentx3-=speed;
    }
    if (currentx4<p.width/2) {
      currentx4+=speed;
      currentx5+=speed;
      currentx6+=speed;
    }
  }
}
