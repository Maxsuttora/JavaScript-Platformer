import processing.core.*;

class Story extends PApplet {
  private PApplet p;
  private float yposition;
  private float xposition;
  private int x;
  private PFont f;
  private int y;
  private int y2;
  private int y3;
  private int y4;

  public Story(PApplet p) {
    this.p = p;
    y= p.height+100;
    y2=p.height+100;
    y3=p.height+100;
    y4= p.height+100;
    xposition = p.width/2;
    yposition = y;
    
  }

  public void displayStory() {
    p.fill(200, 200, 100);
    p.textSize(30);
    p.textAlign(p.CENTER);
    p.text("The year is 478 CE. The proud,\nancient kingdom of Camelot\nis in a time of crisis.\nThe late King Uther has died\nand left the throne empty,\nwith no heir to replace him.\nYou find yourself in the midst a period of instability and fear,\nas knights and nobles of the realm vie for power\nand neighboring kingdoms prepare to invade\nCamelot in its time of weakness.\nIn order to determine who\nwill be the next king of Camelot,\nthe wizard Merlin has placed\nan enchanted sword in a massive stone\noutside of a castle in Caernarfon, Wales.\n The sword bears the inscription\n'Whomsoever is able to pull this sword\nout of the stone is the next\nrightful King of Camelot.'\nYou are a young squire, assisting\nyour uncle Sir Ector as he attempts\nto lay his claim to the throne of Camelot.\nMerlin is a great sorcerer, famous throughout\nthe kingdom and beyond, but he also was your\ntutor growing up, so Sir Ector asks\nyou to find Merlin and have him tell you\nthe secret to pulling out the sword in the stone.\nYour job is to avoid the obstacles\nand find Merlin at the end of the level,\nbut watch out for enemies who will try to stop you!", p.width/2, y);
    p.textSize(17);
    p.fill(255);
    p.text("Press the Space bar to continue", p.width - p.width/5.75f, p.height *9.5f/10);
}

  public void moveStory() {
    
    y--;;
  } 

  public void displayStory2() {
    p.fill(200, 200, 100);
    p.textSize(30);
    p.textAlign(p.CENTER);
    p.text("You have found Merlin, but the\nsecret to getting the sword is not\ngoing to make your uncle, Sir Ector, happy.\nMerlin told you that only the true\nson of Uther Pendragon will be able to take\nthe sword out of the stone.\nAfter enquiring further, Merlin,\nwith a glint in his eye, told you that\nthe true son of Uther never knew his parents,\nand was raised by a surrogate family.\nSir Ector could never have been the son of Uther,\nand would not be able to take the sword out of the stone.\nHowever, you never knew your parents, and grew up\nin Sir Ector’s household. Your task is\nto get to the sword in the stone, and see if YOU\nmight be the true heir to the throne of Camelot.", p.width/2, y2);
    p.textSize(17);
    p.fill(255);
    p.text("Press Space to continue", p.width - p.width/5.75f, p.height *9.5f/10);  
}
  

  public void moveStory2() {
    x=1100;
    y2 = y2 - 1;
  }

  public void displayStory3() {
    p.fill(200, 200, 100);
    p.textSize(30);
    p.textAlign(p.CENTER);
    p.text("You have successfully pulled the Sword\nout of the Stone, which means that you\nare no lowly squire, but the rightful\nheir to the kingdom of Camelot!\nHowever, nobody knows who you are.\nYou will need Merlin’s magical assistance\nto get the rest of the kingdom to accept you\nas king! Use your new skills to defeat\nother nobles who want to be king and get to the throne!\nIt is time to take the throne of Camelot\nas the Legendary King Arthur!", p.width/2, y3);
    p.textSize(17);
    p.fill(255);
    p.text("Press Space to continue", p.width - p.width/5.75f, p.height *9.5f/10);  
}

  public void moveStory3() {
    x = 600;
    y3 = y3 - 1;
  }

  public void displayStory4() {
    p.fill(200, 200, 100);
    p.textSize(30);
    p.textAlign(p.CENTER);
    p.text("You have successfully completed Camelot Quest\nand become King Arthur! It is time\nfor you to take the throne and be crowned king.", p.width/2, y4);
    p.textSize(17);
    p.fill(255);
    p.text("Press Space to continue", p.width - p.width/5.75f, p.height *9.5f/10);  
}

  public void moveStory4() {
    x = 500;
    y4 = y4 - 1;
  }
}
